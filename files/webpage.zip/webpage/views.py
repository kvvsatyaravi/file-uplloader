from django.shortcuts import render
from django.views.generic import TemplateView
from disaster.models import Safeplaces,govt

class testview(TemplateView):
	Template_view="index.html"
	def get(self,request):
                return render(request,self.Template_view)

	def post(self,request):
		if request.method == 'POST':
			num=request.POST.get('input',None)
		context={'data':Safeplaces.objects.get(enteredlocation=num)}
		return render(request,self.Template_view,context)

class adminview(TemplateView):
        Template_name="admin.html"
        Template="loggedin.html"
        def get(self,request):
                return render(request,self.Template_name)                

        def post(self,request):
                if request.method == 'POST':
                        user=request.POST['user']
                        passkey=request.POST['passkey']
                        username=govt.objects.get(username=user)
                        password=govt.objects.get(password=passkey)
                        if username and password:
                            return render(request,self.Template)
                
