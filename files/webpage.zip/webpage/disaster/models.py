from django.db import models
class Safeplaces(models.Model):
#safeplaces
    enteredlocation = models.CharField(max_length=100,default='rjy')
    safeplacesname = models.CharField(max_length=200,default='kkd')
    safeplacesdistance = models.IntegerField(max_length=200,default='23')
    safeplacescapacity = models.IntegerField(max_length=200,default='200')
    safeplacescontact = models.IntegerField(max_length=200,default='5679')

#transport
    transportname = models.CharField(max_length=200,default='orange travels')
    transporttypeof = models.CharField(max_length=200,default='bus')
    transportcontact = models.IntegerField(max_length=200,default='5679')
    
#rescue
    rescueteamtype = models.CharField(max_length=200,default='navy')
    rescueteammembers = models.IntegerField(max_length=200,default='5')
    rescuecontact =models.IntegerField(max_length=200,default='420420')

#hospital
    hospitalname = models.CharField(max_length=200,default='appollo')
    hospitaldistance=models.IntegerField(max_length=1000,default='10')

class govt(models.Model):
#govt offical login
    username = models.CharField(max_length=200,default='null')
    password = models.CharField(max_length=200,default='null')
    
