from django.contrib import admin

from .models import Safeplaces,govt

admin.site.register(Safeplaces)
admin.site.register(govt)


