from django.urls import path
from views import testview,adminview

urlpatterns = [
    path('', testview.as_view(),),
    path('govt/',adminview.as_view(),)
]
